"""Core configuration and cache."""
