"""AI resume analyzer package."""
